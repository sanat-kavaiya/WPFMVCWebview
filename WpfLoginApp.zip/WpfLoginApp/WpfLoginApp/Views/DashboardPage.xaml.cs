﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfLoginApp.Helpers;

namespace WpfLoginApp.Views
{
    /// <summary>
    /// Interaction logic for DashboardPage.xaml
    /// </summary>
    public partial class DashboardPage : Page
    {
        public string CurrentUser { get; set; }
        public DashboardPage()
        {
            InitializeComponent();
            CurrentUser = SessionManager.GetSession();
            DataContext = this; // Set the page as the data context
        }
    }
}
