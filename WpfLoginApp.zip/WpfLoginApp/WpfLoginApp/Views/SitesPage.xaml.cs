﻿using Microsoft.Web.WebView2.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfLoginApp.Views
{
    /// <summary>
    /// Interaction logic for SitesPage.xaml
    /// </summary>
    public partial class SitesPage : Page
    {
        public SitesPage()
        {
            InitializeComponent();
            Loaded += SitesPage_Loaded;
        }
        private async void SitesPage_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                // Create a persistent user data folder
                string userDataFolder = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "WpfLoginApp",           // Your app name
                    "WebView2Data"            // Folder for WebView2 data
                );

                // Check folder age (optional cleanup)
                var dir = new DirectoryInfo(userDataFolder);
                if (dir.Exists && DateTime.Now - dir.LastWriteTime > TimeSpan.FromDays(30))
                {
                    // Folder older than 30 days, clean it
                    Directory.Delete(userDataFolder, true);
                }
                    // Ensure directory exists
                    Directory.CreateDirectory(userDataFolder);

                // Create WebView2 environment with persistent storage
                var environment = await CoreWebView2Environment.CreateAsync(
                    userDataFolder: userDataFolder
                );

                // Initialize WebView with this environment
                await WebView.EnsureCoreWebView2Async(environment);

                // Navigate to your MVC app
                // WebView.CoreWebView2.Navigate("https://localhost:7247/");
                WebView.CoreWebView2.Navigate("https://www.youtube.com/");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error initializing WebView: {ex.Message}");
            }
        }

        // Optional: Method to clear cookies (call this on logout if needed)
        public async Task ClearCookiesAsync()
        {
            if (WebView?.CoreWebView2 != null)
            {
                var cookieManager = WebView.CoreWebView2.CookieManager;
                var cookies = await cookieManager.GetCookiesAsync("https://localhost:7247");

                foreach (var cookie in cookies)
                {
                    cookieManager.DeleteCookie(cookie);
                }
            }
        }
    }
}
