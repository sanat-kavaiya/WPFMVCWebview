﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfLoginApp.Helpers;

namespace WpfLoginApp.Views
{
    /// <summary>
    /// Interaction logic for HomeWindow.xaml
    /// </summary>
    public partial class HomeWindow : Window
    {
        public HomeWindow()
        {
            InitializeComponent();
            Loaded += Dashboard_Click;
        }
        private void Dashboard_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new DashboardPage());
        }

        //private void Settings_Click(object sender, RoutedEventArgs e)
        //{
        //    MainFrame.Navigate(new SettingsPage());
        //}

        private async void Logout_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
      "Are you sure you want to logout?",
      "Confirm",
      MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                // If Sites page is currently loaded, clear its cookies
                if (MainFrame.Content is SitesPage sitesPage)
                {
                    await sitesPage.ClearCookiesAsync();
                }
                SessionManager.ClearSession();

                new LoginWindow().Show();

                this.Close();
            }
        }

        private void Sites_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new SitesPage());
        }
    }
}
